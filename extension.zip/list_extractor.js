// マルチサイト対応スナイパー v5
(() => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const clean = t => (t || "").replace(/\s+/g, " ").trim();

  /* =========================================================
     高値要素定義
     ========================================================= */
  const HIGH_MATERIALS = [
    "カシミヤ","モヘア","シルク","ウール","リネン","レザー","スエード","アンゴラ","アルパカ",
    "cashmere","mohair","silk","wool","linen","leather","suede"
  ];
  // 高値色（ネイビー・ブラック系のみ残す）
  const HIGH_COLORS = ["ブラック","ネイビー","black","navy"];
  // XL以上のサイズのみ高値扱い
  const HIGH_SIZES  = ["XL","XXL","2XL","3XL","44","46","48","50","52"];
  const HIGH_WORDS  = ["コラボ","限定","collab","limited","supreme","off-white","offwhite"];

  // 除外する一般素材・色（検索キーワードに含めない）
  const COMMON_MATERIALS = [
    "コットン","ポリエステル","ナイロン","アクリル","レーヨン","綿","化繊",
    "cotton","polyester","nylon","acrylic","rayon"
  ];
  const COMMON_COLORS = [
    "ホワイト","レッド","ピンク","イエロー","オレンジ","パープル","ベージュ",
    "グレー","ブラウン","white","red","pink","yellow","orange","purple",
    "beige","gray","grey","brown","GRY","BLK","WHT","NVY","BEI"
  ];

  /* =========================================================
     セカスト専用：通称名マッピング
     カテゴリ文字列 → 検索で使いやすい通称
     ========================================================= */
  const CATEGORY_ALIAS = {
    "パーカー": "パーカー", "フーディ": "パーカー", "フーディー": "パーカー",
    "スウェット": "スウェット", "スエット": "スウェット", "トレーナー": "スウェット",
    "Tシャツ": "Tシャツ", "ティーシャツ": "Tシャツ",
    "デニム": "デニム", "ジーンズ": "デニム", "ジーパン": "デニム",
    "ジャケット": "ジャケット", "ブルゾン": "ブルゾン",
    "コート": "コート", "ダウン": "ダウンジャケット",
    "カーディガン": "カーディガン", "ニット": "ニット",
    "シャツ": "シャツ", "ポロシャツ": "ポロシャツ",
    "パンツ": "パンツ", "スラックス": "スラックス", "チノ": "チノパン",
    "スカート": "スカート", "ワンピース": "ワンピース",
    "カレッジ": "カレッジ", "スタジャン": "スタジャン",
    "トラックジャケット": "トラックジャケット", "トラックパンツ": "トラックパンツ",
    "ベスト": "ベスト", "タンクトップ": "タンクトップ",
    "キャップ": "キャップ", "ハット": "ハット", "ニット帽": "ニット帽",
    "バッグ": "バッグ", "リュック": "リュック", "トート": "トートバッグ",
    "スニーカー": "スニーカー", "ブーツ": "ブーツ",
  };

  /* =========================================================
     サイト定義
     ========================================================= */
  const SITE_CONFIG = {
    "2ndstreet": {
      test: u => u.hostname.includes("2ndstreet.jp") && u.pathname.startsWith("/search"),
      linkSelector: 'a[href*="/goods/detail/goodsId/"]',
      normalizeUrl: href => normalizeDetailUrl(href),
      hasLens: true
    },
    "kindal": {
      test: u => u.hostname.includes("shop.kind.co.jp") && u.pathname.startsWith("/search"),
      linkSelector: 'a[href*="/products/"]',
      normalizeUrl: href => normalizeDetailUrl(href),
      hasLens: true
    },
    "trefac": {
      test: u => u.hostname.includes("trefac.jp") && u.pathname.includes("search"),
      linkSelector: 'a[href*="/store/"]',
      normalizeUrl: href => normalizeDetailUrl(href),
      hasLens: true,
      filterLink: link => {
        const href = link.getAttribute("href") || "";
        return /\/store\/\d{10,}\//.test(href) && !!link.querySelector("img");
      }
    },
    "yahooauction": {
      test: u => u.hostname.includes("auctions.yahoo.co.jp") &&
        (u.pathname.startsWith("/search") || u.pathname.startsWith("/closedsearch")),
      linkSelector: 'a[href*="/auction/"]',
      normalizeUrl: href => normalizeDetailUrl(href),
      hasLens: false
    }
  };

  function detectSite() {
    try {
      const u = new URL(location.href);
      for (const [key, cfg] of Object.entries(SITE_CONFIG)) {
        if (cfg.test(u)) return { key, cfg };
      }
    } catch {}
    return null;
  }

  function normalizeDetailUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.origin);
      u.searchParams.delete("srsltid");
      return u.toString();
    } catch { return null; }
  }

  /* =========================================================
     Toast
     ========================================================= */
  const TOAST_ID = "__sniper_toast__";
  let toastTimer = null;
  function showToast(message, ms = 2400) {
    try {
      let el = document.getElementById(TOAST_ID);
      if (!el) {
        el = document.createElement("div");
        el.id = TOAST_ID;
        el.style.cssText = "position:fixed;left:12px;right:12px;bottom:72px;z-index:2147483647;" +
          "background:rgba(17,24,39,0.95);color:#fff;padding:10px 12px;border-radius:12px;" +
          "box-shadow:0 10px 30px rgba(0,0,0,0.25);font-size:13px;line-height:1.3;" +
          "font-family:system-ui,sans-serif;pointer-events:none;" +
          "transform:translateY(6px);opacity:0;transition:opacity 120ms ease,transform 120ms ease";
        document.documentElement.appendChild(el);
      }
      el.textContent = message;
      requestAnimationFrame(() => { el.style.opacity = "1"; el.style.transform = "translateY(0px)"; });
      if (toastTimer) clearTimeout(toastTimer);
      toastTimer = setTimeout(() => {
        const e2 = document.getElementById(TOAST_ID); if (!e2) return;
        e2.style.opacity = "0"; e2.style.transform = "translateY(6px)";
        setTimeout(() => { const e3 = document.getElementById(TOAST_ID); if (e3) e3.remove(); }, 180);
      }, ms);
    } catch {}
  }

  /* =========================================================
     起動モーダル
     ========================================================= */
  const UI_ID = "__sniper_modal__";
  const safeRemoveModal = () => { const r = document.getElementById(UI_ID); if (r) r.remove(); };

  function chooseStartMode(siteName) {
    safeRemoveModal();
    return new Promise(resolve => {
      const root = document.createElement("div");
      root.id = UI_ID;
      root.style.cssText = "position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.45);" +
        "display:flex;align-items:center;justify-content:center;padding:14px";
      const panel = document.createElement("div");
      panel.style.cssText = "width:min(520px,100%);background:#fff;border-radius:14px;" +
        "padding:14px;font-family:system-ui,sans-serif";
      const title = document.createElement("div");
      title.textContent = siteName + " スナイパー";
      title.style.cssText = "font-size:16px;font-weight:700;margin:0 0 8px";
      const desc = document.createElement("div");
      desc.textContent = "分析ボタンを各商品に配置します。";
      desc.style.cssText = "font-size:13px;color:#333;margin:0 0 12px";
      const btnWrap = document.createElement("div");
      btnWrap.style.cssText = "display:grid;gap:10px";
      const mkBtn = (text, sub, mode, bg, color, border) => {
        const b = document.createElement("button");
        b.type = "button";
        b.style.cssText = "width:100%;text-align:left;padding:12px;border-radius:12px;" +
          "background:" + bg + ";color:" + color + ";border:1px solid " + border + ";" +
          "font-size:14px;cursor:pointer";
        b.innerHTML = '<div style="font-weight:700;margin:0 0 4px">' + text +
          '</div><div style="font-size:12px;opacity:.8">' + sub + '</div>';
        b.onclick = () => { safeRemoveModal(); resolve(mode); };
        return b;
      };
      btnWrap.append(
        mkBtn("実行", "商品一覧に分析ボタンを配置します", "run", "#111827", "#fff", "#111827"),
        mkBtn("キャンセル", "何もせず終了します", "abort", "#fff", "#b91c1c", "#fecaca")
      );
      panel.append(title, desc, btnWrap);
      root.append(panel);
      root.onclick = e => { if (e.target === root) { safeRemoveModal(); resolve("abort"); } };
      document.documentElement.append(root);
    });
  }

  /* =========================================================
     汎用ユーティリティ
     ========================================================= */
  function getDtValue(doc, keywords) {
    // dt→dd、th→td（nextElementSibling or 同行td）すべて対応
    const labels = [...doc.querySelectorAll("dt,th,.label,.item-label,.spec-name")];
    for (const label of labels) {
      if (keywords.some(k => clean(label.textContent).includes(k))) {
        const next = label.nextElementSibling;
        if (next) return clean(next.textContent);
        // th が tr 内にある場合、同じ tr 内の td を探す
        const tr = label.closest("tr");
        if (tr) {
          const td = tr.querySelector("td");
          if (td) return clean(td.textContent);
        }
      }
    }
    return "";
  }

  function getJsonLd(doc) {
    for (const s of doc.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        const j = JSON.parse(s.textContent);
        const obj = Array.isArray(j) ? j[0] : j;
        if (obj["@type"] === "Product" || obj.name) return obj;
      } catch {}
    }
    return null;
  }

  // 型番パターン（全サイト対応強化版）
  function extractModelCode(text) {
    const patterns = [
      // UEO011A-206-49 など：英数字-数字-数字（3セグメント）
      /\b([A-Z]{1,4}\d{2,}[A-Z]?-\d{2,}-\d{2,})\b/i,
      // CT2933-100 / UEO011A-206 など：英字+数字-数字
      /\b([A-Z]{1,4}\d{3,}[A-Z]?-\d{2,}[A-Z0-9]*)\b/i,
      // 23-03150M / 14-00713M など：数字2桁-数字4桁以上+末尾英字任意
      /\b(\d{2}-\d{4,}[A-Z]?)\b/,
      // NT11601R / HR8693 など：英字1〜4+数字4桁以上+末尾英字任意
      /\b([A-Z]{1,4}\d{4,}[A-Z]?)\b/i,
      // 既存：英字-数字 (A03-05001)
      /\b([A-Z]{1,5}-\d{3,}[A-Z0-9-]*)\b/i,
      // 既存：英字+数字 (AB1234X)
      /\b([A-Z]{2,}\d{3,}[A-Z0-9]*)\b/,
      // 既存：数字+英字 (1234AB)
      /\b(\d{3,}[A-Z]{2,}[A-Z0-9-]*)\b/,
    ];
    for (const p of patterns) {
      const m = text.match(p);
      if (m) return m[1];
    }
    return "";
  }

  // 高値要素抽出
  function extractHighValueFactors(allText, sizeText) {
    const factors = [];
    const t = allText.toLowerCase();
    for (const m of HIGH_MATERIALS) {
      if (t.includes(m.toLowerCase())) factors.push(m);
    }
    for (const c of HIGH_COLORS) {
      if (t.includes(c.toLowerCase())) factors.push(c);
    }
    if (sizeText) {
      for (const s of HIGH_SIZES) {
        if (sizeText.toUpperCase().includes(s)) { factors.push(s); break; }
      }
    }
    for (const w of HIGH_WORDS) {
      if (t.includes(w.toLowerCase())) factors.push(w);
    }
    return [...new Set(factors)];
  }

  // 一般素材・色・サイズ記号を除去してクリーンな商品名に
  function cleanItemName(raw) {
    if (!raw) return "";
    let name = raw.split("/")[0].trim();
    name = name.replace(/\b[A-Z]{1,5}-\d{3,}[A-Z0-9-]*\b/gi, "");
    name = name.replace(/\b[A-Z]{2,}\d{3,}[A-Z0-9-]*\b/g, "");
    for (const m of COMMON_MATERIALS) name = name.replace(new RegExp(m, "gi"), "");
    for (const c of COMMON_COLORS)    name = name.replace(new RegExp(c, "gi"), "");
    name = name.replace(/\b(XS|S|M|L|XL|XXL|2XL|3XL|\d{2,3}cm|\d{2}号)\b/gi, "");
    name = name.replace(/[/\\|_,、。・]+/g, " ").replace(/\s+/g, " ").trim();
    return name;
  }

  /* =========================================================
     ★ セカスト専用パーサー v5
     productName の /区切り構造を解析して
     ブランド・商品名・サイズ・高値要素を取得する
     ========================================================= */
  function parse2ndStreetProductName(doc) {
    const el = doc.querySelector('[itemprop="name"], .productName, h1[class*="productName"]');
    if (!el) return null;

    const raw = clean(el.textContent);
    const slots = raw.split("/").map(s => s.trim()).filter(s => s.length > 0);
    if (slots.length < 2) return null;

    // --- 型番：末尾から逆順に「英数字のみ・ハイフン許容」スロットを探す ---
    const EXCLUDE_MODEL = new Set([
      ...COMMON_MATERIALS.map(m => m.toLowerCase()),
      ...COMMON_COLORS.map(c => c.toLowerCase())
    ]);
    const isModelCandidate = s =>
      /^[A-Z0-9][A-Z0-9\-]{2,}$/i.test(s) &&   // 英数字・ハイフンのみ
      !EXCLUDE_MODEL.has(s.toLowerCase()) &&      // 一般色・素材でない
      !/^(XS|S|M|L|XL|XXL|2XL|3XL)$/i.test(s) && // サイズでない
      !/^\d{2,4}[sS]$/.test(s);                  // 年代タグでない
    let modelCode = "";
    for (let i = slots.length - 1; i >= 0; i--) {
      if (isModelCandidate(slots[i])) { modelCode = slots[i]; break; }
    }

    // --- ブランド：英字を含む最初のスロット（日本語混在OK）---
    let brand = "";
    let brandIdx = -1;
    for (let i = 0; i < slots.length; i++) {
      const s = slots[i];
      if (/[A-Za-z]/.test(s) && !isModelCandidate(s) && !/^\d{2,4}[sS]$/.test(s)) {
        // 英字部分のみ抽出（"HARVARD  パーカー" → "HARVARD"）
        const m = s.match(/^([A-Za-z][A-Za-z0-9 ]*)/);
        brand = m ? m[1].trim() : s;
        brandIdx = i;
        break;
      }
    }

    // --- カテゴリ：日本語を含む最初の意味のあるスロット ---
    // ブランドスロットに日本語が混在していればそれを使う
    // 例: "HARVARD  パーカー" → "パーカー"
    let category = "";
    if (brandIdx >= 0) {
      const brandSlot = slots[brandIdx];
      const jpMatch = brandSlot.match(/([\u3040-\u9FFF][\u3040-\u9FFF\s]*)/);
      if (jpMatch) category = jpMatch[1].trim();
    }
    // ブランドスロットに日本語がなければ他のスロットから探す
    if (!category) {
      for (let i = 0; i < slots.length; i++) {
        const s = slots[i];
        if (i === brandIdx || s === modelCode) continue;
        if (/[\u3040-\u9FFF]/.test(s) && !/^[0-9]+$/.test(s)) {
          // 最初の日本語カテゴリスロット
          const alias = CATEGORY_ALIAS[s];
          category = alias || s;
          break;
        }
      }
    }

    // --- 高値要素：XL以上・年代・高値素材・高値ワード ---
    const highFactors = [];
    const allText = slots.join(" ").toLowerCase();
    for (const s of slots) {
      if (/^(XL|XXL|2XL|3XL|44|46|48|50|52)$/i.test(s)) { highFactors.push(s.toUpperCase()); break; }
    }
    const eraMatch = slots.find(s => /^\d{2,4}[sS]$/.test(s));
    if (eraMatch) highFactors.push(eraMatch);
    for (const m of HIGH_MATERIALS) {
      if (allText.includes(m.toLowerCase())) highFactors.push(m);
    }
    for (const w of HIGH_WORDS) {
      if (allText.includes(w.toLowerCase())) highFactors.push(w);
    }

    // itemName = カテゴリ（kw2の中核）
    const itemName = category;

    return {
      brand,
      itemName,
      modelCode,
      highValueFactors: [...new Set(highFactors)]
    };
  }

  /* =========================================================
     トレファク専用パーサー
     型番：td.gddescription_detail_data[0]
     商品名：p.gdname
     ========================================================= */
  function parseTrefac(doc) {
    // 型番：「型番」ラベル（th）の同行td を取得
    // 例: <th>型番</th><td class="gddescription_detail_data">CT2933-100</td>
    let modelCode = getDtValue(doc, ["型番","品番","モデル番号"]);
    if (!modelCode) {
      // fallback: td.gddescription_detail_data を全探索
      const tdCells = [...doc.querySelectorAll("td.gddescription_detail_data")];
      for (const td of tdCells) {
        const t = clean(td.textContent);
        if (/^[A-Z0-9][A-Z0-9\-]{2,}$/i.test(t) && t.length <= 20) {
          modelCode = t; break;
        }
      }
    }
    const itemNameEl = doc.querySelector("p.gdname");
    const rawName = clean(itemNameEl?.textContent || "");

    // ブランドと商品名を分離（"adidas　トラックパンツ" → brand:adidas, item:トラックパンツ）
    let brand = "";
    let itemName = rawName;
    const spaceMatch = rawName.match(/^([A-Za-z0-9 ]+?)[　\s]+(.+)$/);
    if (spaceMatch) {
      brand    = spaceMatch[1].trim();
      itemName = spaceMatch[2].trim();
    }

    // サイズ
    const sizeEl = doc.querySelector("p.gdsize");
    const sizeText = clean(sizeEl?.textContent || "");
    const sizeMatch = sizeText.match(/タグ表記サイズ[：:]\s*([^\s（(]+)/);
    const size = sizeMatch ? sizeMatch[1] : "";

    const scopeText = [rawName, size].join(" ");
    const highValueFactors = extractHighValueFactors(scopeText, size);

    return { brand, itemName, modelCode, highValueFactors };
  }

  /* =========================================================
     カインドオル専用パーサー
     h1.product-title に「商品名+型番」が混在
     例: "ボタンブルゾン14-00713M"
     ========================================================= */
  function parseKindal(doc) {
    const h1 = doc.querySelector("h1.product-title, h1");
    const rawName = clean(h1?.textContent || "");

    // 型番：「型番」ラベル（dt）の直後の dd を取得
    // 例: <dt>型番</dt><dd>TSAWF301SZ Boa Fleece Jacket</dd>
    let modelCode = getDtValue(doc, ["型番","品番","モデル番号","model no","sku"]);
    // getDtValueで取れた場合、先頭の英数字部分のみ抽出（商品名が混入している場合）
    // 例: "TSAWF301SZ Boa Fleece Jacket" → "TSAWF301SZ"
    if (modelCode) {
      const firstToken = modelCode.split(/[\s\u3000]/)[0];
      if (/^[A-Z0-9][A-Z0-9\-]{2,}$/i.test(firstToken)) modelCode = firstToken;
    }
    if (!modelCode) modelCode = extractModelCode(rawName);

    // ブランドはdt/ddから
    let brand = getDtValue(doc, ["ブランド","brand"]);
    const jld = getJsonLd(doc);
    if (!brand && jld) brand = (typeof jld.brand === "object" ? jld.brand.name : jld.brand) || "";
    brand = clean(brand);

    // 商品名：rawNameから型番除去
    let itemName = rawName.replace(modelCode, "").trim();
    itemName = cleanItemName(itemName);

    const size = getDtValue(doc, ["サイズ","size"]);
    const scopeText = [rawName, size, getDtValue(doc, ["素材","material"])].join(" ");
    const highValueFactors = extractHighValueFactors(scopeText, size);

    return { brand, itemName, modelCode, highValueFactors };
  }

  /* =========================================================
     ヤフオク専用パーサー
     h1タグ直接取得（クラス名が動的ハッシュのため）
     例: "adidas アディダス GD9923 ロゴプリント パーカー sizeL/イエロー"
     ========================================================= */
  function parseYahooAuction(doc) {
    const h1 = doc.querySelector("h1");
    const rawName = clean(h1?.textContent || "");

    // 型番を抽出
    const modelCode = extractModelCode(rawName);

    // ブランド候補：先頭の英字部分
    let brand = "";
    const brandMatch = rawName.match(/^([A-Za-z][A-Za-z0-9 ]*?)[\s　]/);
    if (brandMatch) brand = brandMatch[1].trim();

    // 商品名：ブランド部分を除いてクリーンアップ
    let itemName = rawName;
    if (brand) {
      // "adidas アディダス ..." → カタカナのブランド名表記も除去
      itemName = itemName.replace(new RegExp("^" + brand + "[\\s　]+"), "");
      // カタカナブランド名（先頭カタカナ列）も除去
      itemName = itemName.replace(/^[\u30A0-\u30FF]+[\s　]+/, "");
    }
    itemName = cleanItemName(itemName);

    // サイズ（"sizeL" "sizeXL" などの表記）
    const sizeMatch = rawName.match(/size([A-Z0-9]+)/i);
    const size = sizeMatch ? sizeMatch[1].toUpperCase() : "";

    const highValueFactors = extractHighValueFactors(rawName, size);

    return { brand, itemName, modelCode, highValueFactors };
  }

  /* =========================================================
     商品情報抽出メイン（サイト別に振り分け）
     ========================================================= */
  function extractProductInfo(doc, siteKey) {
    // セカスト
    if (siteKey === "2ndstreet") {
      const result = parse2ndStreetProductName(doc);
      if (result) return result;
      // fallback: 汎用
    }
    // トレファク
    if (siteKey === "trefac") {
      return parseTrefac(doc);
    }
    // カインドオル
    if (siteKey === "kindal") {
      return parseKindal(doc);
    }
    // ヤフオク
    if (siteKey === "yahooauction") {
      return parseYahooAuction(doc);
    }

    // ===== 汎用フォールバック =====
    const jld = getJsonLd(doc);
    let brand = getDtValue(doc, ["ブランド","brand"]);
    if (!brand && jld) brand = (typeof jld.brand === "object" ? jld.brand.name : jld.brand) || "";
    if (!brand) brand = clean(doc.querySelector("h1")?.textContent || "");
    brand = clean(brand);

    let size = getDtValue(doc, ["サイズ","size"]);
    if (!size && jld) size = jld.size || "";
    size = clean(size);

    const h1 = doc.querySelector("h1");
    let rawName = h1 ? clean(h1.textContent) : (jld?.name || "");
    let itemName = rawName;
    if (brand && itemName.toLowerCase().startsWith(brand.toLowerCase())) {
      itemName = itemName.slice(brand.length).trim();
    }
    itemName = cleanItemName(itemName);

    let modelCode = getDtValue(doc, ["型番","品番","モデル番号","model","sku"]);
    if (!modelCode && jld) modelCode = jld.mpn || jld.sku || "";
    if (!modelCode) modelCode = extractModelCode(rawName);
    if (!modelCode) {
      for (const el of doc.querySelectorAll("p,li,td,dd,span")) {
        const code = extractModelCode(clean(el.textContent));
        if (code) { modelCode = code; break; }
      }
    }
    modelCode = clean(modelCode);

    const scopeText = [rawName, size, getDtValue(doc, ["素材","material"])].join(" ");
    const highValueFactors = extractHighValueFactors(scopeText, size);

    return { brand, itemName, modelCode, highValueFactors };
  }

  /* =========================================================
     画像URL取得
     ========================================================= */
  function extractImageUrl(doc, siteKey) {
    if (siteKey === "trefac") {
      const i = doc.querySelector("img[src*='/image/item/']");
      if (i && i.src) return i.src.replace(/\/w\d+\//, "/w800/");
    }
    for (const sel of ["main img",".slick-slide img",".goodsMainImage img",".item-main img","img"]) {
      const i = doc.querySelector(sel);
      if (i && i.src) return i.src;
    }
    return "";
  }

  /* =========================================================
     詳細ページfetch
     ========================================================= */
  async function fetchDetailInfo(url, siteKey) {
    try {
      const r = await fetch(url, { credentials: "include" });
      const html = await r.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const info = extractProductInfo(doc, siteKey); // ← siteKeyを渡す
      return { imageUrl: extractImageUrl(doc, siteKey), ...info };
    } catch {
      return { imageUrl: "", brand: "", itemName: "", modelCode: "", highValueFactors: [] };
    }
  }

  /* =========================================================
     Google Lens POST
     ========================================================= */
  async function openLensWithBlob(imageUrl, brand) {
    if (!imageUrl) return;
    let blob = null;
    try {
      const res = await fetch(imageUrl, { mode: "cors", credentials: "omit" });
      blob = await res.blob();
    } catch {
      try {
        blob = await new Promise((resolve, reject) => {
          const img = new Image(); img.crossOrigin = "anonymous";
          img.onload = () => {
            const c = document.createElement("canvas");
            c.width = img.width; c.height = img.height;
            c.getContext("2d").drawImage(img, 0, 0);
            c.toBlob(b => b ? resolve(b) : reject(), "image/jpeg", 0.9);
          };
          img.onerror = reject;
          img.src = imageUrl;
        });
      } catch {
        showToast("画像取得失敗 — Lensをスキップします", 2400);
        return;
      }
    }
    const searchKw = (brand ? brand + " " : "") + "メルカリ";
    const file = new File([blob], "image.jpg", { type: "image/jpeg" });
    const newWin = window.open("", "_blank");
    if (!newWin) { showToast("ポップアップをブロックされています", 2400); return; }
    const d = newWin.document;
    d.open();
    d.write('<html><head><meta name="referrer" content="no-referrer"></head>' +
      '<body style="background:#0f172a;color:#fff;text-align:center;padding-top:20%">' +
      '<p>Lensへ転送中...</p></body></html>');
    d.close();
    await sleep(200);
    const form = d.createElement("form");
    form.method = "POST";
    form.action = "https://lens.google.com/upload?ep=gisbubu&hl=ja&q=" + encodeURIComponent(searchKw);
    form.enctype = "multipart/form-data";
    const inp = d.createElement("input");
    inp.type = "file"; inp.name = "encoded_image";
    const dt = new DataTransfer(); dt.items.add(file); inp.files = dt.files;
    form.appendChild(inp); d.body.appendChild(form); form.submit();
  }

  /* =========================================================
     サブメニュー
     ========================================================= */
  const SUB_ID = "__sniper_sub__";
  function safeRemoveSub() { const r = document.getElementById(SUB_ID); if (r) r.remove(); }

  function showSubMenu(anchorEl, info, detailUrl, siteKey) {
    safeRemoveSub();
    const { brand, itemName, modelCode, highValueFactors, imageUrl } = info;

    // kw1: 型番
    const kw1 = modelCode || null;

    // kw2: ブランド + 商品名 + 高値要素（スペース結合）
    const kw2parts = [brand, itemName, ...highValueFactors].filter(Boolean);
    const kw2 = kw2parts.length ? kw2parts.join(" ") : null;

    const menu = document.createElement("div");
    menu.id = SUB_ID;
    const rect = anchorEl.getBoundingClientRect();
    const top  = rect.bottom + window.scrollY + 4;
    const left = Math.min(rect.left + window.scrollX, window.innerWidth - 230);
    menu.style.cssText =
      "position:absolute;top:" + top + "px;left:" + left + "px;" +
      "z-index:2147483647;background:#1e293b;border:1px solid rgba(255,255,255,0.15);" +
      "border-radius:12px;padding:8px;min-width:220px;" +
      "box-shadow:0 8px 24px rgba(0,0,0,0.5);font-family:system-ui,sans-serif";

    const mkRow = (icon, label, sub, onclick) => {
      const row = document.createElement("button");
      row.type = "button";
      row.style.cssText =
        "display:flex;align-items:flex-start;gap:8px;width:100%;" +
        "background:none;border:none;color:#e2e8f0;padding:8px 10px;" +
        "border-radius:8px;cursor:pointer;text-align:left";
      row.innerHTML =
        '<span style="font-size:16px;flex-shrink:0">' + icon + '</span>' +
        '<span><span style="display:block;font-size:13px;font-weight:700">' + label + '</span>' +
        (sub ? '<span style="display:block;font-size:11px;color:#64748b;word-break:break-all">' +
          sub + '</span>' : '') + '</span>';
      row.onmouseenter = () => row.style.background = "rgba(255,255,255,0.07)";
      row.onmouseleave = () => row.style.background = "none";
      row.onclick = () => { safeRemoveSub(); onclick(); };
      return row;
    };

    const sep = () => {
      const d = document.createElement("div");
      d.style.cssText = "height:1px;background:rgba(255,255,255,0.08);margin:4px 0";
      return d;
    };

    // 📄 詳細ページ
    menu.appendChild(mkRow("📄", "詳細ページを開く", "", () => window.open(detailUrl, "_blank")));

    // 🔎 Lens（ヤフオクはなし）
    if (siteKey !== "yahooauction") {
      menu.appendChild(mkRow("🔎", "Lensで検索", brand || "",
        async () => await openLensWithBlob(imageUrl, brand)));
    }

    menu.appendChild(sep());

    // 🛍️ ① 型番検索
    if (kw1) {
      menu.appendChild(mkRow("🛍️", "① 型番検索", kw1,
        () => window.open(buildMercariUrl(kw1), "_blank")));
    } else {
      menu.appendChild(mkRow("🛍️", "① 型番検索", "（型番取得できず）",
        () => showToast("型番が取得できませんでした", 2000)));
    }

    // 🛍️ ② ブランド＋商品名＋高値要素
    if (kw2) {
      menu.appendChild(mkRow("🛍️", "② ブランド＋商品名", kw2,
        () => window.open(buildMercariUrl(kw2), "_blank")));
    }

    document.documentElement.appendChild(menu);

    setTimeout(() => {
      document.addEventListener("click", function handler(e) {
        if (!menu.contains(e.target)) {
          safeRemoveSub();
          document.removeEventListener("click", handler);
        }
      });
    }, 100);
  }

  /* =========================================================
     メルカリURL構築
     ========================================================= */
  function buildMercariUrl(keyword) {
    return "https://jp.mercari.com/search?keyword=" + encodeURIComponent(keyword) +
      "&item_condition_id=3&category_id=11%2C12%2C13%2C14%2C15%2C27%2C1488%2C163%2C30%2C31%2C32%2C35" +
      "&status=sold_out&seller_type=0&item_types=mercari&sort=created_time&order=desc";
  }

  /* =========================================================
     ボタン注入
     ========================================================= */
  function injectAnalysisButtons(cfg, siteKey) {
    const items = document.querySelectorAll(cfg.linkSelector);
    let addedCount = 0;

    items.forEach(link => {
      if (cfg.filterLink ? !cfg.filterLink(link) : !link.querySelector("img")) return;
      if (link.dataset.sniperBtn) return;
      link.dataset.sniperBtn = "true";

      link.style.position = "relative";
      if (window.getComputedStyle(link).display === "inline") link.style.display = "inline-block";

      const btn = document.createElement("button");
      btn.textContent = "🔍分析";
      btn.style.cssText =
        "position:absolute;right:4px;top:4px;z-index:2147483647;" +
        "background:rgba(220,38,38,0.95);color:#fff;border:2px solid #fff;" +
        "border-radius:6px;padding:8px 12px;font-size:12px;font-weight:bold;" +
        "box-shadow:0 4px 12px rgba(0,0,0,0.5);pointer-events:auto;line-height:1";

      btn.onclick = async (e) => {
        e.preventDefault();
        e.stopPropagation();
        safeRemoveSub();
        const orig = btn.textContent;
        btn.textContent = "⏳...";
        try {
          const detailUrl = cfg.normalizeUrl(link.getAttribute("href"));
          if (!detailUrl) return;
          const info = await fetchDetailInfo(detailUrl, siteKey);
          btn.textContent = orig;
          showSubMenu(btn, info, detailUrl, siteKey);
        } catch (err) {
          console.error("分析エラー:", err);
          btn.textContent = orig;
        }
      };

      link.appendChild(btn);
      addedCount++;
    });

    showToast(
      addedCount > 0
        ? addedCount + "件に分析ボタンを配置しました"
        : "商品が見つからないか、既に配置済みです",
      2600
    );
  }

  /* =========================================================
     メイン
     ========================================================= */
  const SITE_NAMES = {
    "2ndstreet":    "2nd STREET",
    "kindal":       "カインドオル",
    "trefac":       "トレファク",
    "yahooauction": "ヤフオク"
  };

  /* =========================================================
     Google レンズ結果ページ：メルカリリンクにintentボタン注入
     ========================================================= */
  function buildMercariIntent(keyword) {
    return "https://jp.mercari.com/search?keyword=" + encodeURIComponent(keyword);
  }

  // レンズ結果タイトルから不要な suffix を除去
  function cleanLensTitle(raw) {
    return raw
      .replace(/\s*[-–]\s*メルカリ.*$/i, "")   // "- メルカリ" 以降を除去
      .replace(/在庫あり|売り切れ|SOLD/gi, "")   // ステータス除去
      .replace(/\s+/g, " ")
      .trim();
  }

  function injectLensResultButtons() {
    // すでに注入済みならスキップ
    if (document.querySelector("[data-sniper-lens-btn]")) return;

    const links = [...document.querySelectorAll("a[href*='mercari.com']")];
    if (links.length === 0) return;

    let injected = 0;
    links.forEach(link => {
      if (link.dataset.sniperLensBtn) return;
      link.dataset.sniperLensBtn = "true";

      // タイトルテキスト：最初のテキストを持つ子要素から取得
      const titleEl = [...link.querySelectorAll("div, span, p")]
        .find(el => el.children.length === 0 && el.textContent.trim().length > 2);
      const raw = clean(titleEl?.textContent || link.textContent || "");
      const keyword = cleanLensTitle(raw);
      if (!keyword) return;

      const btn = document.createElement("a");
      btn.href = buildMercariIntent(keyword);
      btn.textContent = "📲 メルカリアプリで開く";
      btn.style.cssText =
        "display:block;margin:4px 0 2px;padding:6px 10px;" +
        "background:#FF0211;color:#fff;border-radius:6px;" +
        "font-size:12px;font-weight:700;text-decoration:none;" +
        "font-family:system-ui,sans-serif;line-height:1.4;text-align:center";

      // タイトルテキストの直後に挿入（画像の下）
      const titleParent = titleEl?.parentElement || link.parentElement;
      if (titleParent) {
        titleParent.insertAdjacentElement("afterend", btn);
        injected++;
      }
    });

    if (injected > 0) showToast(injected + "件にアプリ起動ボタンを追加しました", 2000);
  }

  function isLensResultPage() {
    const u = new URL(location.href);
    return (u.hostname.includes("google.com") &&
      (u.pathname.includes("/search") || u.pathname.includes("/lens")));
  }

  async function main() {
    // Googleレンズ結果ページ処理
    if (isLensResultPage()) {
      // 初回実行
      await sleep(1500); // ページ描画待ち
      injectLensResultButtons();
      return;
    }

    const site = detectSite();
    if (!site) return;
    const mode = await chooseStartMode(SITE_NAMES[site.key] || site.key);
    if (mode === "abort") return;
    // 既存ボタンをリセット
    document.querySelectorAll("[data-sniper-btn]").forEach(el => delete el.dataset.sniperBtn);
    document.querySelectorAll("button").forEach(b => {
      if (b.textContent === "🔍分析" || b.textContent === "⏳...") b.remove();
    });
    injectAnalysisButtons(site.cfg, site.key);
  }

  main().catch(e => console.error(e));
})();
