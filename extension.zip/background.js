// アイコンタップ時（仕入れ4サイト用）
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["list_extractor.js"]
    });
  } catch (e) {
    console.error("list_extractor 実行エラー:", e);
  }
});
